# Zip-testfixture

Denna lilla fixture används av `[PLAN2 Prompt 13]` för att verifiera att arbetsflödet kan läsa, inventera, ändra och packa om ett projekt.

## Ursprungligt tillstånd

- status: original
- värde: 1

## Ändrat tillstånd

- status: modified
- värde: 2
